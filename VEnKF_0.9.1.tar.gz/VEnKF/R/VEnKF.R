#' VEnKF: Ensemble Kalman Filter using the Vecchia approximation
#' 
#' This package can be used for filerting large spatio-temporal datasets
#' 
#' @docType package
#' @name VEnKF
#' @useDynLib VEnKF
#' @importFrom Rcpp sourceCpp
#' 
NULL